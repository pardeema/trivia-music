Music Rounds Creator - macOS

Installation:
1. Extract this ZIP file to a folder of your choice
2. Double-click MusicRoundsCreator to run the application
3. If macOS blocks the app, right-click and select "Open" from the context menu

Requirements:
- macOS 10.14 (Mojave) or later
- No additional software required (all dependencies included)

Usage:
1. Enter YouTube URLs and start times
2. Click "Create Music Round"
3. Find your ZIP file on the Desktop

For support, contact the developer.
